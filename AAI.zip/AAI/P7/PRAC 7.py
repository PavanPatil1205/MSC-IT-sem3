import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import MinMaxScaler

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.optimizers import Adam


# --------------------------------------------------
# Step 1: Create a sample time-series dataset
# --------------------------------------------------

np.random.seed(42)

# Create 120 months of data
months = pd.date_range(
    start="2015-01-01",
    periods=120,
    freq="ME"
)

# Create a trend + seasonal pattern + random noise
values = (
    100
    + np.arange(120) * 0.5
    + 10 * np.sin(np.arange(120) * 2 * np.pi / 12)
    + np.random.normal(0, 2, 120)
)

dataframe = pd.DataFrame({
    "Date": months,
    "Value": values
})

print(dataframe.head())


# --------------------------------------------------
# Step 2: Prepare the data
# --------------------------------------------------

data = dataframe["Value"].values.reshape(-1, 1)


# --------------------------------------------------
# Step 3: Normalize the data
# --------------------------------------------------

scaler = MinMaxScaler(feature_range=(0, 1))

scaled_data = scaler.fit_transform(data)


# --------------------------------------------------
# Step 4: Create sequences
# --------------------------------------------------

def create_sequences(data, time_step=12):

    X = []
    y = []

    for i in range(len(data) - time_step):

        X.append(
            data[i:i + time_step]
        )

        y.append(
            data[i + time_step]
        )

    return np.array(X), np.array(y)


# Use previous 12 months
time_step = 12

X, y = create_sequences(
    scaled_data,
    time_step
)


# --------------------------------------------------
# Step 5: Reshape data for LSTM
# --------------------------------------------------

X = X.reshape(
    X.shape[0],
    X.shape[1],
    1
)

print("X shape:", X.shape)
print("y shape:", y.shape)


# --------------------------------------------------
# Step 6: Build the LSTM model
# --------------------------------------------------

model = Sequential()

model.add(
    LSTM(
        units=50,
        return_sequences=True,
        input_shape=(X.shape[1], 1)
    )
)

model.add(
    LSTM(
        units=50,
        return_sequences=False
    )
)

model.add(
    Dense(1)
)


# --------------------------------------------------
# Step 7: Compile the model
# --------------------------------------------------

model.compile(
    optimizer=Adam(learning_rate=0.001),
    loss="mean_squared_error"
)


# --------------------------------------------------
# Step 8: Train the model
# --------------------------------------------------

model.fit(
    X,
    y,
    epochs=20,
    batch_size=16,
    verbose=1
)


# --------------------------------------------------
# Step 9: Make predictions
# --------------------------------------------------

predictions = model.predict(X)


# --------------------------------------------------
# Step 10: Convert predictions back to original scale
# --------------------------------------------------

predictions = scaler.inverse_transform(
    predictions
)


# --------------------------------------------------
# Step 11: Plot actual and predicted values
# --------------------------------------------------

actual_values = data[time_step:]

plt.figure(figsize=(12, 6))

plt.plot(
    actual_values,
    label="True Values"
)

plt.plot(
    predictions,
    label="Predictions"
)

plt.title("LSTM Time Series Prediction")

plt.xlabel("Time")

plt.ylabel("Value")

plt.legend()

plt.show()
