# Install required libraries
# Run this in terminal or Google Colab:
# pip install ultralytics requests opencv-python matplotlib

from ultralytics import YOLO
import cv2
import numpy as np
import requests
from matplotlib import pyplot as plt

# 1. Load the pre-trained YOLOv8 model

model = YOLO("yolov8n.pt")

# 2. Download the image from a URL

image_url = "https://i.sstatic.net/UYYqo.jpg"

response = requests.get(image_url)

# Check whether image was downloaded successfully
if response.status_code != 200:
    raise Exception("Failed to download the image.")

# Convert downloaded data into an image
image_array = np.asarray(
    bytearray(response.content),
    dtype=np.uint8
)

image = cv2.imdecode(
    image_array,
    cv2.IMREAD_COLOR
)

# Check whether image was decoded successfully
if image is None:
    raise Exception("Could not decode the image.")

# 3. Convert BGR to RGB for visualization

image_rgb = cv2.cvtColor(
    image,
    cv2.COLOR_BGR2RGB
)

# 4. Perform object detection

results = model(image)

# 5. Draw bounding boxes and labels

results_image = results[0].plot()

# Convert BGR to RGB for matplotlib
results_image_rgb = cv2.cvtColor(
    results_image,
    cv2.COLOR_BGR2RGB
)

# 6. Display detected image

plt.figure(figsize=(10, 10))
plt.imshow(results_image_rgb)
plt.axis("off")
plt.show()

# 7. Print detected objects and confidence scores

print("Detected Objects:")

for result in results[0].boxes:

    # Get class ID
    class_id = int(result.cls[0])

    # Get object name
    object_name = model.names[class_id]

    # Get confidence score
    confidence = float(result.conf[0])

    print(
        f"Object: {object_name}, "
        f"Confidence: {confidence:.2f}"
    )
