from transformers import GPT2LMHeadModel, GPT2Tokenizer
import os

# Suppress TensorFlow logs
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

# Suppress Hugging Face symlink warnings
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"


def chatbot():
    # Load pre-trained GPT-2 model and tokenizer
    print("Loading model...")
    model_name = "gpt2"  # You can replace this with 'gpt2-medium'

    # Load the tokenizer and model
    tokenizer = GPT2Tokenizer.from_pretrained(model_name)
    model = GPT2LMHeadModel.from_pretrained(model_name)

    # Set a padding token (GPT-2 doesn't have one by default)
    tokenizer.pad_token = tokenizer.eos_token

    print("Model loaded successfully!")
    print("\nChatbot ready! Type 'exit' to quit.\n")

    # Chat loop
    while True:
        user_input = input("You: ")

        if user_input.lower() == "exit":
            print("Chatbot: Goodbye!")
            break

        # Tokenize the input
        inputs = tokenizer(
            user_input,
            return_tensors="pt",
            padding=True,
            truncation=True
        )

        input_ids = inputs["input_ids"]
        attention_mask = inputs["attention_mask"]

        # Generate the response
        output = model.generate(
            input_ids,
            attention_mask=attention_mask,
            max_length=100,
            num_return_sequences=1,
            pad_token_id=tokenizer.pad_token_id
        )

        # Decode the response
        response = tokenizer.decode(output[0], skip_special_tokens=True)

        # Remove the user's prompt from the generated output
        chatbot_reply = response[len(user_input):].strip()

        print(f"Chatbot: {chatbot_reply}")


# Run the chatbot
if __name__ == "__main__":
    chatbot()
