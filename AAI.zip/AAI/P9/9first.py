import optuna
import numpy as np

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score


# --------------------------------------------------
# Step 1: Load the Iris dataset
# --------------------------------------------------

data = load_iris()

X = data.data
y = data.target


# --------------------------------------------------
# Step 2: Split the dataset
# --------------------------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)


# --------------------------------------------------
# Step 3: Define Optuna objective function
# --------------------------------------------------

def objective(trial):

    # Define hyperparameters to tune

    n_estimators = trial.suggest_int(
        "n_estimators",
        10,
        100
    )

    max_depth = trial.suggest_int(
        "max_depth",
        3,
        10
    )

    min_samples_split = trial.suggest_int(
        "min_samples_split",
        2,
        10
    )

    min_samples_leaf = trial.suggest_int(
        "min_samples_leaf",
        1,
        5
    )


    # --------------------------------------------------
    # Create Random Forest model
    # --------------------------------------------------

    model = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_split=min_samples_split,
        min_samples_leaf=min_samples_leaf,
        random_state=42
    )


    # --------------------------------------------------
    # Train the model
    # --------------------------------------------------

    model.fit(
        X_train,
        y_train
    )


    # --------------------------------------------------
    # Make predictions
    # --------------------------------------------------

    y_pred = model.predict(
        X_test
    )


    # --------------------------------------------------
    # Calculate accuracy
    # --------------------------------------------------

    accuracy = accuracy_score(
        y_test,
        y_pred
    )

    return accuracy


# --------------------------------------------------
# Step 4: Create Optuna study
# --------------------------------------------------

study = optuna.create_study(
    direction="maximize"
)


# --------------------------------------------------
# Step 5: Optimize hyperparameters
# --------------------------------------------------

study.optimize(
    objective,
    n_trials=50
)


# --------------------------------------------------
# Step 6: Display best results
# --------------------------------------------------

print("\nBest Hyperparameters:")
print(study.best_params)

print("\nBest Accuracy:")
print(study.best_value)
