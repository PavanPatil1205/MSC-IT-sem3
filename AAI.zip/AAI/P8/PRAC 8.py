import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.datasets import load_iris
from sklearn.metrics import accuracy_score

from tpot import TPOTClassifier


# --------------------------------------------------
# Step 1: Load the Iris dataset
# --------------------------------------------------

data = load_iris()

X = pd.DataFrame(
    data.data,
    columns=data.feature_names
)

y = pd.Series(data.target)


print("Dataset:")
print(X.head())

print("\nTarget:")
print(y.head())


# --------------------------------------------------
# Step 2: Split data into training and testing sets
# --------------------------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)


# --------------------------------------------------
# Step 3: Handle missing values
# --------------------------------------------------

imputer = SimpleImputer(
    strategy="mean"
)

X_train = imputer.fit_transform(X_train)
X_test = imputer.transform(X_test)


# --------------------------------------------------
# Step 4: Standardize the features
# --------------------------------------------------

scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)


# --------------------------------------------------
# Step 5: Create TPOT AutoML model
# --------------------------------------------------

tpot = TPOTClassifier(
    generations=5,
    population_size=20,
    random_state=42,
    verbosity=2
)


# --------------------------------------------------
# Step 6: Train TPOT
# --------------------------------------------------

tpot.fit(
    X_train,
    y_train
)


# --------------------------------------------------
# Step 7: Make predictions
# --------------------------------------------------

y_pred = tpot.predict(
    X_test
)


# --------------------------------------------------
# Step 8: Evaluate the model
# --------------------------------------------------

accuracy = accuracy_score(
    y_test,
    y_pred
)

print("\nAccuracy:", round(accuracy, 4))


# --------------------------------------------------
# Step 9: Export the best pipeline
# --------------------------------------------------

tpot.export(
    "best_model_pipeline.py"
)

print("\nBest model pipeline exported successfully.")
