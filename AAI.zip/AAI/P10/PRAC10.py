from tpot import TPOTClassifier

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score


# --------------------------------------------------
# Step 1: Load the Iris dataset
# --------------------------------------------------

data = load_iris()

X = data.data
y = data.target


# --------------------------------------------------
# Step 2: Split the dataset
# --------------------------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)


# --------------------------------------------------
# Step 3: Create TPOT AutoML model
# --------------------------------------------------

tpot = TPOTClassifier(
    generations=5,
    population_size=20,
    random_state=42
)


# --------------------------------------------------
# Step 4: Train the model
# --------------------------------------------------

print("Starting TPOT optimization...")

tpot.fit(
    X_train,
    y_train
)


# --------------------------------------------------
# Step 5: Make predictions
# --------------------------------------------------

y_pred = tpot.predict(
    X_test
)


# --------------------------------------------------
# Step 6: Calculate accuracy
# --------------------------------------------------

accuracy = accuracy_score(
    y_test,
    y_pred
)

print("\nAccuracy:", round(accuracy, 4))


# --------------------------------------------------
# Step 7: Export best pipeline
# --------------------------------------------------

tpot.export(
    "best_model_pipeline.py"
)

print("\nBest model pipeline saved successfully.")
