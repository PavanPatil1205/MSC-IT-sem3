import numpy as np

from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, Flatten, Dense, Concatenate
from sklearn.model_selection import train_test_split

# Sample data (user, item, rating)
data = np.array([
    [1, 101, 5],
    [1, 102, 3],
    [2, 101, 4],
    [2, 103, 2],
    [3, 102, 4],
    [3, 104, 1]
])

users = data[:, 0]
items = data[:, 1]
ratings = data[:, 2]

# Encode user IDs
user_ids = {id_: idx for idx, id_ in enumerate(np.unique(users))}
users = np.array([user_ids[u] for u in users])

# Encode item IDs
item_ids = {id_: idx for idx, id_ in enumerate(np.unique(items))}
items = np.array([item_ids[i] for i in items])

# Normalize ratings from 0 to 1
ratings = (ratings - ratings.min()) / (ratings.max() - ratings.min())

# Train-test split
train_users, test_users, train_items, test_items, train_ratings, test_ratings = train_test_split(
    users,
    items,
    ratings,
    test_size=0.2,
    random_state=42
)

# Number of unique users and items
num_users = len(np.unique(users))
num_items = len(np.unique(items))

# Model architecture
user_input = Input(shape=(1,))
item_input = Input(shape=(1,))

# User and item embeddings
user_embedding = Embedding(
    input_dim=num_users,
    output_dim=50
)(user_input)

item_embedding = Embedding(
    input_dim=num_items,
    output_dim=50
)(item_input)

# Convert embeddings into vectors
user_vec = Flatten()(user_embedding)
item_vec = Flatten()(item_embedding)

# Combine user and item vectors
concat = Concatenate()([user_vec, item_vec])

# Neural network layer
dense = Dense(128, activation='relu')(concat)

# Output rating
output = Dense(1, activation='sigmoid')(dense)

# Create model
model = Model(
    inputs=[user_input, item_input],
    outputs=output
)

# Compile model
model.compile(
    optimizer='adam',
    loss='mse',
    metrics=['mae']
)

# Train model
model.fit(
    [train_users, train_items],
    train_ratings,
    epochs=10,
    batch_size=16,
    verbose=1
)

# Predict ratings
predicted_ratings = model.predict(
    [test_users, test_items]
)

print("Predicted Normalized Ratings:")
print(predicted_ratings.flatten())
