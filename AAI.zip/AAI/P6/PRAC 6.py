import numpy as np
import random

# --------------------------------------------------
# 1. Define the environment
# --------------------------------------------------

grid_size = 5

# Starting position
start = (0, 0)

# Goal position
goal = (4, 4)

# Obstacles
obstacles = [
    (1, 1),
    (2, 3),
    (3, 1)
]

# --------------------------------------------------
# 2. Q-learning parameters
# --------------------------------------------------

alpha = 0.1       # Learning rate
gamma = 0.9       # Discount factor
epsilon = 0.1     # Exploration rate
episodes = 1000   # Number of training episodes

# --------------------------------------------------
# 3. Initialize Q-table
# --------------------------------------------------

# 4 actions:
# 0 = Up
# 1 = Down
# 2 = Left
# 3 = Right

q_table = np.zeros(
    (grid_size, grid_size, 4)
)

# --------------------------------------------------
# 4. Define actions
# --------------------------------------------------

actions = {
    0: (-1, 0),   # Up
    1: (1, 0),    # Down
    2: (0, -1),   # Left
    3: (0, 1)     # Right
}

# --------------------------------------------------
# 5. Check whether a position is valid
# --------------------------------------------------

def is_valid_position(pos):
    """
    Check if the position is inside the grid
    and not an obstacle.
    """

    x, y = pos

    # Check grid boundaries
    if x < 0 or x >= grid_size:
        return False

    if y < 0 or y >= grid_size:
        return False

    # Check obstacles
    if pos in obstacles:
        return False

    return True


# --------------------------------------------------
# 6. Get the next state
# --------------------------------------------------

def get_next_state(state, action):
    """
    Return the next position after taking an action.
    """

    x, y = state

    dx, dy = actions[action]

    next_state = (
        x + dx,
        y + dy
    )

    # If movement is valid
    if is_valid_position(next_state):
        return next_state

    # Otherwise stay in the same position
    return state


# --------------------------------------------------
# 7. Define rewards
# --------------------------------------------------

def get_reward(state):
    """
    Return reward for the given state.
    """

    # Reaching the goal
    if state == goal:
        return 10

    # Hitting an obstacle
    if state in obstacles:
        return -10

    # Normal movement
    return -1


# --------------------------------------------------
# 8. Train the Q-learning agent
# --------------------------------------------------

for episode in range(episodes):

    # Start from (0, 0)
    state = start

    total_reward = 0

    # Continue until goal is reached
    while state != goal:

        # ------------------------------------------
        # Choose action using epsilon-greedy strategy
        # ------------------------------------------

        if random.uniform(0, 1) < epsilon:

            # Explore
            action = random.choice(
                list(actions.keys())
            )

        else:

            # Exploit
            action = np.argmax(
                q_table[
                    state[0],
                    state[1]
                ]
            )

        # ------------------------------------------
        # Take action
        # ------------------------------------------

        next_state = get_next_state(
            state,
            action
        )

        # Get reward
        reward = get_reward(next_state)

        # ------------------------------------------
        # Q-learning update
        # ------------------------------------------

        old_value = q_table[
            state[0],
            state[1],
            action
        ]

        next_max = np.max(
            q_table[
                next_state[0],
                next_state[1]
            ]
        )

        # Q-learning formula
        new_value = old_value + alpha * (
            reward +
            gamma * next_max -
            old_value
        )

        q_table[
            state[0],
            state[1],
            action
        ] = new_value

        # Move to next state
        state = next_state

        total_reward += reward

    # Print progress
    if (episode + 1) % 100 == 0:

        print(
            f"Episode {episode + 1}, "
            f"Total Reward: {total_reward}"
        )


# --------------------------------------------------
# 9. Test the trained agent
# --------------------------------------------------

state = start

path = [state]

while state != goal:

    # Select best action
    action = np.argmax(
        q_table[
            state[0],
            state[1]
        ]
    )

    # Move to next state
    state = get_next_state(
        state,
        action
    )

    path.append(state)


# --------------------------------------------------
# 10. Display optimal path
# --------------------------------------------------

print("\nOptimal Path:")
print(path)
